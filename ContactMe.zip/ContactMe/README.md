# Client Organizer

This is a mobile application for INF654 Mobile Web Development. This application organizes a list of clients

## Description

The purpose of this application is to show my web development skills I learned in class. I used JavaScript to use a fetch of users from JSONplaceholder dot com. This will demonstrate how data will be pulled from a database. Soon I would like to add functionality to remove and add users. 

Most of the work I implemented in the app are added in playground.js file.  

I dynamically added the card data to allow future functionality of adding and deleting contacts in the client organizer

## Authors

Cierra Ray
I used the demo project from class to build of off for more development in the course. 


# License
This project is an ongoing project for class and is not to be redistributed. 

